%% Gaussian Filter // G = FXH
im = imread('panda.jpeg'); % or insert an image
hsize = 31;
% sigma = 5;
% h = fspecial('gaussian', hsize, sigma);
% figure();
% surf(h);
% figure();
% imagesc(h);
% outim = imfilter(im,h);
% figure();
% imshow(outim);

for sigma = 1:3:10
    h = fspecial('gaussian', hsize, sigma);
    out = imfilter(im, h);
    figure();
    imshow(out);
end