% Apply a Gaussian filter to remove noise
img = imread('panda.jpeg');
imshow(img);

% TODO: Add noise to the image
noise_sigma = 25;
noise = randn().*noise_sigma;
img_noise = img + noise;
figure();
imshow(img_noise);

% TODO: Now apply a Gaussian filter to smooth out the noise
f_size = 10;
f_sigma = 2;
h = fspecial('gaussian',f_size, f_sigma);
smoothed = imfilter(img_noise, h);
figure();
imshow(smoothed);