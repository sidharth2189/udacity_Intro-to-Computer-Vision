% Explore Edge options
% 0         - clip
% circular  - wrap around
% replicate - copy edge
% symmetric - reflect across edge

% Load an image
img = imread('panda.jpeg');
%imshow(img);

% Create a Gaussian Filter
filter_size = 21;
filter_sigma = 3;
filter = fspecial('gaussian', filter_size, filter_sigma);

%% Apply it, specifying an edge parameter
smoothed = imfilter(img, filter, 0);
figure();
imshow(smoothed);