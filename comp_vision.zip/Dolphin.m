% Load and display an image
img = imread('dolphin.jpg');
imshow(img);

% Image size:
disp(size(img));

% % Image class or data type:
% disp(class(img));
% 
% % At a given location:
% disp(img(50,100));
% 
% % Value for entire row:
% plot(img(50,:))

% % cropping
% cropped = img(110:210, 10:160);
% imshow(cropped);

% selecting a channel
img_red = img(:,:,1);
imshow(img_red);
disp(size(img_red));
plot(img_red(150,:));