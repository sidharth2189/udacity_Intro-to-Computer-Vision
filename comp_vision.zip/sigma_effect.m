%% Higher the standard deviation, higher the noise.
%% In other words, multiplying a value by a normally distributed set of numbers ...
%% effectively changes the spread of distribution they were drawn from

im = imread('dolphin.jpg');
noise = randn(size(im));
% plot(noise(:,2,1));

for sigma = 1:1:3
    plot(noise(:,1,1).*sigma);
    hold on;
end
legend('sigma = 1','sigma = 2', 'sigma = 3')
hold off
