% Generate Gaussian noise
noise = randn([2 10000]);
[n1, x] = hist(noise(1,:), linspace(-3, 3, 21));
[n2, x] = hist(noise(2,:), linspace(-3, 3, 21));
%disp([x; n1]);
%disp([x; n2]);
plot(x, n1);
hold on
plot(x,n2);
